# import modules
from machine import UART
from machine import Pin
import time
import uasyncio as asyncio


MAX_MESSAGE_LEN = 64
MAX_SEND_RATE = 5  # Maximum messages per second

# Define team IDs and broadcast ID
team = [b'\x01', b'\x02', b'\x03', b'\x04']  # Cade, Jahmel, Tyler, Dan
id = b'\x01'  # Set this device's ID (e.g., Cade)
broadcast = b'\x58'  # Broadcast ID

# initialize a new UART class
uart = UART(2, 9600, tx=17, rx=16)
# run the init method with more details including baudrate and parity
uart.init(9600, bits=8, parity=None, stop=1)
# define pin 2 as an output with name led. (Pin 2 is connected to the ESP32-WROOM dev board's onboard blue LED)
led = Pin(2, Pin.OUT)


def send_message(source, destination, message_type, sensor_id=None, status=None, temp_data_integer=None, temp_data_fraction=None, fan_id=None, fan_speed_data=None, fan_speed_set=None):
    """
    Sends a message with the specified structure.
    """
    if source not in team:
        print(f"ESP: Invalid source '{source}'")
        return
    if destination not in team and destination != broadcast:
        print(f"ESP: Invalid destination '{destination}'")
        return

    # Construct the message
    message = bytearray(64)
    message[0] = 65  # prefix_1 (0x41 in decimal)
    message[1] = 90  # prefix_2 (0x5A in decimal)
    message[2] = source[0]  # source_id
    message[3] = destination[0]  # destination_id
    message[4] = message_type  # message_type

    if message_type == 16:  # Temp Data (0x10 in decimal)
        if not (0 <= temp_data_integer <= 255):
            print("ESP: Temperature data out of range (0 to 155)")
            return
        message[5] = sensor_id  # sensor_id
        message[6] = status  # status
        message[7] = temp_data_integer  # temp_data_integer
        message[8] = temp_data_fraction  # temp_data_fraction

    elif message_type == 32:  # Fan Control (0x20 in decimal)
        if not (1 <= fan_id <= 255):
            print("ESP: Fan ID out of range (1 to 255)")
            return
        if status not in [0, 1]:  # 0x00 and 0x01 in decimal
            print("ESP: Invalid fan status (must be 0 or 1)")
            return
        if not (0 <= fan_speed_data <= 3):
            print("ESP: Fan speed data out of range (0 to 3)")
            return
        if not (0 <= fan_speed_set <= 3):
            print("ESP: Fan speed set value out of range (0 to 3)")
            return
        message[5] = fan_id  # fan_id
        message[6] = status  # status
        message[7] = fan_speed_data  # fan_speed_data
        message[8] = fan_speed_set  # fan_speed_set

    else:
        print("ESP: Invalid message type")
        return

    # Unused bytes are already initialized to 0 by default
    message[62] = 89  # suffix_1 (0x59 in decimal)
    message[63] = 66  # suffix_2 (0x42 in decimal)

    print(f"ESP: Sending message: {message}")
    uart.write(message)


def handle_message(message):
    """
    Handles an incoming message by parsing its structure.
    Processes messages intended for this device and passes on others.
    """
    if len(message) != 64:
        print("ESP: Invalid message length")
        return

    # Parse the message
    prefix_1 = message[0]
    prefix_2 = message[1]
    source_id = message[2]
    destination_id = message[3]
    message_type = message[4]
    suffix_1 = message[62]
    suffix_2 = message[63]

    # Validate prefixes and suffixes
    if prefix_1 != 0x41 or prefix_2 != 0x5A or suffix_1 != 0x59 or suffix_2 != 0x42:
        print("ESP: Invalid message format")
        return

    # Ignore messages from myself
    if source_id == id[0]:
        print("ESP: Ignoring message from myself")
        return

    # Process messages intended for this device
    if destination_id == id[0]:
        print("ESP: Message is for me")
        if message_type == 0x10:  # Temp Data
            sensor_id = message[5]
            status = message[6]
            temp_data_integer = message[7]
            temp_data_fraction = message[8]

            if not (0 <= temp_data_integer <= 255):
                print("ESP: Received temperature data out of range (0 to 255)")
                return

            print(f"ESP: Handling Temp Data message")
            print(f"Sensor ID: {sensor_id}, Status: {status}, Temperature: {temp_data_integer}.{temp_data_fraction}")

        elif message_type == 0x20:  # Fan Control
            fan_id = message[5]
            status = message[6]
            fan_speed_data = message[7]
            fan_speed_set = message[8]

            if not (1 <= fan_id <= 255):
                print("ESP: Received invalid fan ID (1 to 255)")
                return
            if status not in [0x00, 0x01]:
                print("ESP: Received invalid fan status (must be 0x00 or 0x01)")
                return
            if not (0 <= fan_speed_data <= 3):
                print("ESP: Received invalid fan speed data (0 to 3)")
                return
            if not (0 <= fan_speed_set <= 3):
                print("ESP: Received invalid fan speed set value (0 to 3)")
                return

            print(f"ESP: Handling Fan Control message")
            print(f"Fan ID: {fan_id}, Status: {status}, Fan Speed Data: {fan_speed_data}, Fan Speed Set: {fan_speed_set}")

    # Pass on messages intended for others
    elif destination_id != id[0] and destination_id != broadcast[0]:
        print("ESP: Passing on message for another device")
        uart.write(message)

    else:
        print("ESP: Unsupported message type or invalid destination")


async def process_rx():
    """
    Processes incoming messages over the UART network.
    Handles messages intended for this device, passes on messages for others,
    and ignores invalid or self-sent messages.
    """
    stream = b''
    receiving_message = False

    while True:
        # Read one byte
        c = uart.read(1)

        # If a byte is received
        if c is not None:
            stream += c

            # Check for message start
            if stream[-2:] == b'AZ' and not receiving_message:
                # Start a new message
                receiving_message = True
                stream = b'AZ'  # Reset stream to only include the prefix

            # Check for message end
            elif stream[-2:] == b'YB' and receiving_message:
                # Complete the message
                receiving_message = False
                message = stream  # Copy the full message
                stream = b''  # Clear the stream

                # Validate message length
                if len(message) != MAX_MESSAGE_LEN:
                    print(f"ESP: Invalid message length ({len(message)}), ignoring")
                    continue

                # Handle the received message
                handle_message(message)
                led.value(led.value() ^ 1)  # Toggle LED
                continue

            # Abort if message exceeds buffer size
            elif receiving_message and len(stream) > MAX_MESSAGE_LEN:
                print("ESP: Message too long, aborting")
                receiving_message = False
                stream = b''

        await asyncio.sleep_ms(10)


async def send_example_messages():
    """
    Sends examples of each message type with time-varying data.
    Ensures proper formatting and adheres to the maximum send rate.
    """
    last_send_time = time.ticks_ms()

    while True:
        # Ensure the maximum send rate
        current_time = time.ticks_ms()
        if time.ticks_diff(current_time, last_send_time) < (1000 // MAX_SEND_RATE):
            await asyncio.sleep_ms(10)
            continue

        # Example Temp Data message
        send_message(
            source=id,
            destination=b'\x02',  # Example destination
            message_type=16,  # 0x10 in decimal
            sensor_id=1,  # 0x01 in decimal
            status=0,  # 0x00 in decimal
            temp_data_integer=25,
            temp_data_fraction=50
        )

        # Example Fan Control message
        send_message(
            source=b'\x04',
            destination=id,  # Example destination
            message_type=32,  # 0x20 in decimal
            fan_id=2,
            status=0,  # 0x01 in decimal
            fan_speed_data=2,
            fan_speed_set=1
        )

        # Example Temp Data message
        send_message(
            source=b'\x02',
            destination=b'\x01',  # Example destination
            message_type=16,  # 0x10 in decimal
            sensor_id=1,  # 0x01 in decimal
            status=0,  # 0x00 in decimal
            temp_data_integer=140,
            temp_data_fraction=12
        )

        last_send_time = current_time
        await asyncio.sleep(7)  # Wait before sending the next batch


async def main():
    """
    Main function to run the asynchronous tasks.
    """
    asyncio.create_task(process_rx())
    asyncio.create_task(send_example_messages())

    while True:
        await asyncio.sleep(1)


# Run the main event loop
try:
    asyncio.run(main())
finally:
    asyncio.new_event_loop()